public class Player {
    int playerPosX = 10;
    int playerPosY = 10;
    char player = 'P';

    public int getPlayerPosX() {
        return playerPosX;
    }

    public int getPlayerPosY() {
        return playerPosY;
    }

    public char getPlayer() {
        return player;
    }
}
